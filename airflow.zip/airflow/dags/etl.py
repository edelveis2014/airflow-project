
from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.bash_operator import BashOperator
from airflow.utils.dates import days_ago

import sys
import logging
import pandas as pd
import mysql.connector
from mysql.connector import errorcode


logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

def connectToDb(ds, **kwargs):

    try:
        cnx = mysql.connector.connect(
                user='root', password='redhat',
                host='127.0.0.1', database='',
                auth_plugin='mysql_native_password')

        cursor = cnx.cursor()

        # Create a seperate database named airflow
        cursor.execute("CREATE DATABASE IF NOT EXISTS {} DEFAULT CHARACTER SET 'utf8'".format('airflow'))

        cursor.execute("USE {}".format('airflow'))

        cursor.execute("DROP TABLE IF EXISTS {}".format('Employee'))
        # table schema
        cursor.execute(
                "CREATE TABLE IF NOT EXISTS`Employee` ("
                "  `Prefix` varchar(100),"
                "  `FirstName` varchar(100),"
                "  `Middle Name` varchar(100),"
                "  `LastName` varchar(50),"
                "  `Suffix` varchar(100),"
                "  `Phone` varchar(1000),"
                "  `Address` varchar(1000),"
                "  `Email` varchar(100),"
                "  `Ext` varchar(50)"
                ") ENGINE=InnoDB")


        df = pd.read_csv('~/airflow/dags/src/transformed.csv')

        df = df.fillna('NULL')

        cols = "`,`".join([str(i) for i in df.columns.tolist()])

        logging.info('loading data into database, {}'.format(df.shape))

        for i, row in df.iterrows():

            try:

                query = "INSERT INTO `Employee` (`" +cols + "`) VALUES (" + "%s,"*(len(row)-1) + "%s)"

                cursor.execute(query, tuple(row))

                # the connection is not autocommitted by default, so we must commit to save our changes
                cnx.commit()
            except Exception as e:
                logging.info('error: {}'.format(e))

    except:
        pass


default_args = {
        'owner': 'airflow',
        'depends_on_past': False,
        'start_date': days_ago(2),
        'email': ['airflow@example.com'],
        'email_on_failure': False,
        'email_on_retry': False,
        'retries': 1,
        'retry_delay': timedelta(minutes=60*12)
}


# the dag to run everday by using 60 minutes.
dag = DAG(
        dag_id='MY_ETL_Pipeline',
        default_args = default_args,
        start_date = datetime(2020,7,6),
        schedule_interval = timedelta(minutes=60))


t1 = BashOperator(
			task_id='transform_data',
			bash_command='python3 ~/airflow/dags/src/transform.py' ,
			dag=dag)


t2 =  PythonOperator(
			task_id='loadToDb',
			provide_context=True,
			python_callable=connectToDb,
			dag=dag)


t1 >> t2
