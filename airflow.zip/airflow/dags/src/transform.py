#!/usr/bin/env python3

import pandas as pd
import numpy as np
import re
import sys
import logging

logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)


def splitToExt(phone):
    if 'x' in phone:
        return phone.split('x')[1]
    else:
        return np.nan

def removeExt(phone):
    if 'x' in phone:
        return phone.split('x')[0]
    else:
        return phone

def removeCountryCode(phone):

    m = re.match('\+\d+-|00\d+-', phone)

    if m is not None:
        val = m.group()
        return phone.replace(val, "")
    else:
        return phone

def cleanPhoneNumber(phone):
    return phone.replace('(','').replace(')','').replace('.','').replace('-','')

def phoneNumberToAlpha(phone):
    alphaNumber = phone.replace('2', 'abc').replace('3','def').replace('4','ghi').replace('5','jkl').replace('6', 'mno').replace('7', 'pqrs').replace('8',  'tuv').replace('9', 'wxyz')

    return alphaNumber

def transform():

    df = pd.read_csv('~/airflow/dags/src/people_data.csv', sep='\t')


    df['FirstName'] = df['FirstName'].str.strip()
    df['FirstName'] = df['FirstName'].str.upper()

    df['Middle Name'] = df['Middle Name'].str.strip()
    df['Middle Name'] = df['Middle Name'].str.upper()

    df['LastName'] = df['LastName'].str.strip()
    df['LastName'] = df['LastName'].str.upper()

    df['Suffix'] = df['Suffix'].str.strip()
    df['Suffix'] = df['Suffix'].str.upper()

    df['Address'] = df['Address'].str.strip()
    df['Address'] = df['Address'].str.upper()

    df['Email'] = df['Email'].str.strip()
    df['Email'] = df['Email'].str.upper()

    df['Ext'] = np.nan
    

    df['Ext'] = df['Phone'].apply(splitToExt)
    df['Phone'] = df['Phone'].apply(removeExt)
    df['Phone'] = df['Phone'].apply(removeCountryCode)

    df['Phone'] = df['Phone'].apply(cleanPhoneNumber)

    df['Phone'] = df['Phone'].apply(phoneNumberToAlpha)

    df.to_csv('~/airflow/dags/src/transformed.csv',index=False)

    logging.info('Data transformation complete.')

    print(df)


transform()
